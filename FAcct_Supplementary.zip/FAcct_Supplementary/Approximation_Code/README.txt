The folder contains 1 folder each for every dataset. Each dataset contains a folder called Results

Results Contains:
1) The saved files for the DNN model: m1_epoch9_model.pth- this is the model for the first fold trained upto 9 epochs
2) The metrics for our underlying model
eg: for DNN, the file is titled m1 where 1 is the fold number.
Similarly m1_FOLD-SE is the metric for the FOLD-SE approximation of the DNN trained on the first fold for the cross-validation.

eg: for GBC, the file is titled GBC2 where 2 is the fold number.
Similarly gbc2_FOLD-SE is the metric for the FOLD-SE approximation of the gbc trained on the second fold for the cross-validation.
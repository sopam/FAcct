1) Approximation_Code: Contains the code for the underlying model and the metrics of how FOLD-SE performs

2) CoGS_code: Contains our CoGS solution code to obtain a path.

3) Comparison_Code: Contains the code where we compare CoGS to other counterfactual solutions


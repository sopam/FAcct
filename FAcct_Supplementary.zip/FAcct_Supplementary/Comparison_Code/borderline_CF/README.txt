Data: Stored in data/adult and data/german
Outouts: Stored in data/output

How to run:
python wachter.py <name of dataset>

for example:
python wachter.py adult

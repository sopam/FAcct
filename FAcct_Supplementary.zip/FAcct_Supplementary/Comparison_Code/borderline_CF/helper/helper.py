import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler, OneHotEncoder
from sklearn.neural_network import MLPClassifier
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split
from scipy.optimize import minimize

def inverse_transform(preprocessor, transformed_data, original_data):

    # Identify numeric and categorical columns
    numeric_columns = original_data.select_dtypes(include=['int64', 'float64']).columns
    categorical_columns = original_data.select_dtypes(include=['object']).columns

    # Extract individual transformers
    numeric_transformer = preprocessor.named_transformers_['num']
    categorical_transformer = preprocessor.named_transformers_['cat']

    # Determine the numeric part of the transformed data
    num_numeric_features = len(numeric_columns)
    numeric_data = transformed_data[:, :num_numeric_features]

    # Inverse transform numeric data
    original_numeric = numeric_transformer.inverse_transform(numeric_data)

    # Handle the categorical part
    categorical_data = transformed_data[:, num_numeric_features:]

    # Get the feature names of the one-hot encoded features
    onehot_feature_names = categorical_transformer.get_feature_names_out(categorical_columns)

    # Create a DataFrame for the categorical data
    categorical_df = pd.DataFrame(categorical_data, columns=onehot_feature_names)

    # Use idxmax to get the original category for each one-hot encoded feature
    original_categorical = {}
    for i, col in enumerate(categorical_columns):
        # Get columns related to this categorical feature
        feature_cols = [c for c in onehot_feature_names if c.startswith(f"{col}_")]
        feature_data = categorical_df[feature_cols]
        # Find the index of the max value (should be 1)
        idx = feature_data.values.argmax(axis=1)
        # Map index to category
        categories = categorical_transformer.categories_[i]
        original_categorical[col] = categories[idx]

    # Combine numeric and categorical parts
    original_numeric_df = pd.DataFrame(original_numeric, columns=numeric_columns)
    original_categorical_df = pd.DataFrame(original_categorical)
    inverse_transformed_data = pd.concat(
        [original_numeric_df.reset_index(drop=True), original_categorical_df.reset_index(drop=True)], axis=1
    )

    return inverse_transformed_data

def preprocess_data(data, preprocessor=None):

    # Handle missing values
    data = data.replace('?', np.nan).dropna()

    # Separate features and target
    X = data.drop(columns=['label'])  # Adjust 'label' if your target variable has a different name
    y = data['label']

    # Identify numeric and categorical columns
    numeric_columns = X.select_dtypes(include=['int64', 'float64']).columns
    categorical_columns = X.select_dtypes(include=['object']).columns

    # Preprocessor
    if preprocessor is None:
        # Define transformers for numeric and categorical features
        numeric_transformer = StandardScaler()
        categorical_transformer = OneHotEncoder(sparse_output=False, handle_unknown='ignore')

        # Create a ColumnTransformer
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', numeric_transformer, numeric_columns),
                ('cat', categorical_transformer, categorical_columns)
            ]
        )

        # Fit the preprocessor on the training data
        X_transformed = preprocessor.fit_transform(X)
    else:
        # Use the existing preprocessor to transform the data
        X_transformed = preprocessor.transform(X)

    return X_transformed, y, preprocessor


def generate_counterfactual(
    model,
    x_original_df,
    desired_class,
    preprocessor,
    numeric_columns,
    categorical_columns,
    categories,
    regularization=0.01,
    max_iter=1000,
    tol=1e-4,
    max_combinations=100
):


    import itertools

    # Generate all possible combinations of categorical variables
    categorical_values = [list(cat) for cat in categories]
    all_combinations = list(itertools.product(*categorical_values))

    # Limit the number of combinations if necessary
    if len(all_combinations) > max_combinations:
        np.random.seed(42)  # For reproducibility
        indices = np.random.choice(len(all_combinations), size=max_combinations, replace=False)
        all_combinations = [all_combinations[i] for i in indices]

    best_counterfactual = None
    best_categorical_values = None
    best_loss = np.inf

    # For each combination, fix the categorical variables and optimize over numeric variables
    for cat_values in all_combinations:
        # Create a copy of the original instance
        x_candidate_df = x_original_df.copy()

        # Set the categorical variables to the current combination
        for col_name, value in zip(categorical_columns, cat_values):
            x_candidate_df[col_name] = value

        # Preprocess the candidate instance
        x_candidate_preprocessed = preprocessor.transform(x_candidate_df)

        # Identify indices of numeric features in the preprocessed data
        feature_names = preprocessor.get_feature_names_out()
        numeric_feature_indices = [i for i, name in enumerate(feature_names) if name.startswith('num__')]

        # Extract numeric features
        x_numeric = x_candidate_preprocessed[0, numeric_feature_indices]

        # Optimize over numeric features
        def loss_function(cf_x_numeric):
            # Reconstruct the full feature vector
            cf_x = x_candidate_preprocessed.copy()
            cf_x[0, numeric_feature_indices] = cf_x_numeric

            # Obtain the predicted probability for the desired class
            probabilities = model.predict_proba(cf_x)[0]
            prob_desired_class = probabilities[desired_class]

            # Prediction loss using logistic loss
            epsilon = 1e-8
            prediction_loss = -np.log(prob_desired_class + epsilon)

            # Proximity loss
            proximity_loss = regularization * np.linalg.norm(cf_x_numeric - x_numeric)

            return prediction_loss + proximity_loss

        # Define bounds for numeric features
        bounds = [(-3, 3)] * len(numeric_feature_indices)  # Adjust based on your data

        # Optimize
        result = minimize(
            loss_function,
            x0=x_numeric.copy(),
            method='L-BFGS-B',
            bounds=bounds,
            options={'maxiter': max_iter, 'disp': False, 'ftol': tol}
        )

        if result.success:
            # Reconstruct the full counterfactual instance
            cf_x = x_candidate_preprocessed.copy()
            cf_x[0, numeric_feature_indices] = result.x

            # Calculate total loss
            total_loss = loss_function(result.x)

            # Update the best counterfactual if the loss is lower
            if total_loss < best_loss:
                best_loss = total_loss
                best_counterfactual = cf_x
                best_categorical_values = cat_values

    if best_counterfactual is not None:
        return best_counterfactual, best_categorical_values
    else:
        raise ValueError("No valid counterfactual found.")

def obtain_counterfactual_1(
    inp_X_test, arr_index, inp_model, inp_desired_class, inp_label_encoder, inp_train_data, inp_preprocessor
):
    X_test = inp_X_test
    model = inp_model
    desired_class = inp_desired_class
    label_encoder = inp_label_encoder
    train_data = inp_train_data
    preprocessor = inp_preprocessor

    # Identify numeric and categorical columns
    numeric_columns = train_data.drop(columns=['label']).select_dtypes(include=['int64', 'float64']).columns.tolist()
    categorical_columns = train_data.drop(columns=['label']).select_dtypes(include=['object']).columns.tolist()

    # Get categories for each categorical variable
    categorical_transformer = preprocessor.named_transformers_['cat']
    categories = categorical_transformer.categories_

    counterfactuals = []  # List to store counterfactuals

    for i in arr_index:
        cf_instance, cf_display = obtain_counterfactual_2(
            X_test,
            i,
            model,
            desired_class,
            label_encoder,
            train_data,
            preprocessor,
            categories,
            numeric_columns,
            categorical_columns,
        )
        counterfactuals.append(cf_instance)

    # Combine all counterfactuals into a dataframe
    counterfactuals_df = pd.DataFrame(counterfactuals)
    print("\nCounterfactuals DataFrame:")
    print(counterfactuals_df.head())
    return counterfactuals_df


def obtain_counterfactual_2(
    X_test,
    instance_index,
    model,
    desired_class,
    label_encoder,
    train_data,
    preprocessor,
    categories,
    numeric_columns,
    categorical_columns,
):
    original_instance = X_test[instance_index]
    original_prediction = model.predict(original_instance.reshape(1, -1))[0]
    print(f"Original instance prediction: {original_prediction} ({label_encoder.inverse_transform([original_prediction])[0]})")

    # Inverse transform to get original feature values
    original_features_df = inverse_transform(
        preprocessor,
        original_instance.reshape(1, -1),
        train_data.drop(columns=['label'])
    )

    # Generate the counterfactual
    best_counterfactual, best_categorical_values = generate_counterfactual(
        model,
        x_original_df=original_features_df,
        desired_class=desired_class,
        preprocessor=preprocessor,
        numeric_columns=numeric_columns,
        categorical_columns=categorical_columns,
        categories=categories,
        regularization=0.01,
        max_iter=1000,
        tol=1e-4,
        max_combinations=100
    )

    # Predict probabilities for the counterfactual
    counterfactual_probabilities = model.predict_proba(best_counterfactual)[0]
    counterfactual_prediction = np.argmax(counterfactual_probabilities)
    prob_desired_class = counterfactual_probabilities[desired_class]

    print(f"Counterfactual prediction: {counterfactual_prediction} ({label_encoder.inverse_transform([counterfactual_prediction])[0]})")
    print(f"Probability of desired class: {prob_desired_class:.4f}")

    # Inverse transform to get original feature values of the counterfactual
    counterfactual_features_df = inverse_transform(
        preprocessor,
        best_counterfactual,
        train_data.drop(columns=['label'])
    )

    # Display the changes
    print("\nFeature comparison (Original vs. Counterfactual):")
    for feature in original_features_df.columns:
        orig_value = original_features_df.iloc[0][feature]
        cf_value = counterfactual_features_df.iloc[0][feature]
        print(f"{feature}: {orig_value} -> {cf_value}")

    # Return both the counterfactual instance and the display information
    return counterfactual_features_df.iloc[0].to_dict(), (original_features_df, counterfactual_features_df)       



from helper.helper import *

import sys
#src = 'adult'
#src = 'german'

# Extract the first argument as a string
src = sys.argv[1]
print("Finding counterfactuals for the given dataset:", src)


# Specify the column types during CSV loading
dtype_mapping = {
    'education_num': 'object'  # Specify 'education_num' as categorical
}


# Load train and test datasets
train_file = "./data/"+src+"/train_fold_1.csv"  # Replace with your actual file path
test_file = "./data/"+src+"/test_fold_1.csv"    # Replace with your actual file path

train_data = pd.read_csv(train_file, dtype=dtype_mapping)
test_data = pd.read_csv(test_file, dtype=dtype_mapping)

# Preprocess train data and get the preprocessor
X_train, y_train_raw, preprocessor = preprocess_data(train_data)

# Transform test data using the same preprocessor
X_test, y_test_raw, _ = preprocess_data(test_data, preprocessor=preprocessor)

# Fit LabelEncoder on training labels
label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(y_train_raw)

# Transform test labels using the same encoder
y_test = label_encoder.transform(y_test_raw)

# Train an MLP classifier
model = MLPClassifier(hidden_layer_sizes=(50,), activation='relu', solver='adam', max_iter=1000)
model.fit(X_train, y_train)

# Ensure the model supports predict_proba
if not hasattr(model, 'predict_proba'):
    raise ValueError("Model does not support predict_proba.")


# Call the modified function
arr_index = np.where(model.predict(X_test) == 0)[0][:len(X_test)]
batch_size = 10
arr_index = arr_index[:batch_size]
desired_class = 1

# Obtain the counterfactuals and display them
counterfactuals_df = obtain_counterfactual_1(X_test, arr_index, model, desired_class, label_encoder, train_data, preprocessor)

# Save the counterfactuals to a CSV file
output_file = "./data/output/"+src+"_cf_wachter.csv"
counterfactuals_df.to_csv(output_file, index=False)
print(f"\nCounterfactual instances saved to {output_file}")
  
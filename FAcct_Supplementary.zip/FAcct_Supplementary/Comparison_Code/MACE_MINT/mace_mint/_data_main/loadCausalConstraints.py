# TODO: ideally, you would write a new class called CausalModel, M = {X, U, F}
#       where perhaps F can be defined parametrically (e.g., in the case of linear
#       models). This class would have a method that automatically generates the
#       required causal consistency constraints for pysmt.


import numpy as np
from pysmt.shortcuts import *
from pysmt.typing import *
'''
def getGermanCausalConsistencyConstraints(model_symbols, factual_sample):
  # Gender (no parents)
  g = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x0']['symbol']),
        ToReal(factual_sample['x0']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x0']['symbol']),
      ToReal(model_symbols['interventional']['x0']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x0']['symbol']),
      ToReal(factual_sample['x0']),
    ),
  )

  # Age (no parents)
  a = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x1']['symbol']),
        ToReal(factual_sample['x1']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x1']['symbol']),
      ToReal(model_symbols['interventional']['x1']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x1']['symbol']),
      ToReal(factual_sample['x1']),
    ),
  )

  # Credit (parents: age, sex)
  c = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x2']['symbol']),
        ToReal(factual_sample['x2']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x2']['symbol']),
      ToReal(model_symbols['interventional']['x2']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x2']['symbol']),
      Plus([
        ToReal(factual_sample['x2']),
        Times(
          Minus(
            ToReal(model_symbols['counterfactual']['x0']['symbol']),
            ToReal(factual_sample['x0']),
          ),
          # If you want to support numeric-int children, then you should round
          # these structural equation weights.
          # Real(float(552.43925387))
          Real(float(550))
        ),
        Times(
          Minus(
            ToReal(model_symbols['counterfactual']['x1']['symbol']),
            ToReal(factual_sample['x1']),
          ),
          # If you want to support numeric-int children, then you should round
          # these structural equation weights.
          # Real(float(4.4847736))
          Real(float(4.5))
        ),
      ])
    ),
  )

  # Repayment duration (parents: credit)
  r = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x3']['symbol']),
        ToReal(factual_sample['x3']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x3']['symbol']),
      ToReal(model_symbols['interventional']['x3']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x3']['symbol']),
      Plus([
        ToReal(factual_sample['x3']),
        Times(
          Minus(
            ToReal(model_symbols['counterfactual']['x2']['symbol']),
            ToReal(factual_sample['x2']),
          ),
          # If you want to support numeric-int children, then you should round
          # these structural equation weights.
          # Real(float(0.00266995))
          Real(float(0.0025))
        ),
      ])
    ),
  )

  return And([g,a,c,r])
'''
def getGermanCausalConsistencyConstraints(model_symbols, factual_sample):
  # Gender (no parents)
  g = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x0']['symbol']),
        ToReal(factual_sample['x0']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x0']['symbol']),
      ToReal(model_symbols['interventional']['x0']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x0']['symbol']),
      ToReal(factual_sample['x0']),
    ),
  )

  # Age (no parents)
  a = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x1']['symbol']),
        ToReal(factual_sample['x1']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x1']['symbol']),
      ToReal(model_symbols['interventional']['x1']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x1']['symbol']),
      ToReal(factual_sample['x1']),
    ),
  )

  # Credit (parents: age, sex)
  c = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x2']['symbol']),
        ToReal(factual_sample['x2']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x2']['symbol']),
      ToReal(model_symbols['interventional']['x2']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x2']['symbol']),
      Plus([
        ToReal(factual_sample['x2']),
        Times(
          Minus(
            ToReal(model_symbols['counterfactual']['x0']['symbol']),
            ToReal(factual_sample['x0']),
          ),
          # If you want to support numeric-int children, then you should round
          # these structural equation weights.
          # Real(float(552.43925387))
          Real(float(600))
        )
      ])
    ),
  )

  # Repayment duration (parents: credit)
  r = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x3']['symbol']),
        ToReal(factual_sample['x3']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x3']['symbol']),
      ToReal(model_symbols['interventional']['x3']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x3']['symbol']),
      Plus([
        ToReal(factual_sample['x3']),
        Times(
          Minus(
            ToReal(model_symbols['counterfactual']['x2']['symbol']),
            ToReal(factual_sample['x2']),
          ),
          # If you want to support numeric-int children, then you should round
          # these structural equation weights.
          # Real(float(0.00266995))
          Real(float(0.0025))
        ),
      ])
    ),
  )

  return And([g,a,c,r])



def getRandomCausalConsistencyConstraints(model_symbols, factual_sample):
  # x0 (root node; no parents)
  x0 = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x0']['symbol']),
        ToReal(factual_sample['x0']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x0']['symbol']),
      ToReal(model_symbols['interventional']['x0']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x0']['symbol']),
      ToReal(factual_sample['x0']),
    ),
  )

  # x1 (parents = {x0})
  x1 = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x1']['symbol']),
        ToReal(factual_sample['x1']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x1']['symbol']),
      ToReal(model_symbols['interventional']['x1']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x1']['symbol']),
      Plus(
        ToReal(factual_sample['x1']),
        Times(
          Minus(
            ToReal(model_symbols['counterfactual']['x0']['symbol']),
            ToReal(factual_sample['x0']),
          ),
          Real(1)
        )
      )
    ),
  )

  # x2 (parents = {x0, x1})
  x2 = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x2']['symbol']),
        ToReal(factual_sample['x2']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x2']['symbol']),
      ToReal(model_symbols['interventional']['x2']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x2']['symbol']),
      Plus([
        ToReal(factual_sample['x2']),
        Times(
          Minus(
            Times(
              ToReal(model_symbols['counterfactual']['x0']['symbol']),
              Pow(
                ToReal(model_symbols['counterfactual']['x1']['symbol']),
                Real(2)
              ),
            ),
            Times(
              ToReal(factual_sample['x0']),
              Pow(
                ToReal(factual_sample['x1']),
                Real(2)
              ),
            ),
          ),
          Real(float(np.sqrt(3)))
        ),
      ])
    ),
  )

  return And([x0,x1,x2])


'''
def getAdultCausalConsistencyConstraints(model_symbols, factual_sample):
    """
    Define causal consistency constraints for the Adult dataset using SEM-like relationships:
    - Age impacts HoursPerWeek.
    - Sex impacts Relationship.
    - Education impacts Occupation.
    - HoursPerWeek influences CapitalGain.

    Args:
        model_symbols (dict): Dictionary containing the model symbols for the counterfactual and interventional samples.
        factual_sample (dict): The factual sample from the dataset.

    Returns:
        pysmt.formula.FNode: A conjunction of all causal consistency constraints.
    """
    
    # Initialize constraints list
    constraints = []

    # Rule 1: If Age is intervened, then set the counterfactual to the intervened value
    constraints.append(
        Ite(
            Not(EqualsOrIff(ToReal(model_symbols['interventional']['x1']['symbol']), ToReal(factual_sample['x1']))),
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x1']['symbol']), ToReal(model_symbols['interventional']['x1']['symbol'])),
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x1']['symbol']), ToReal(factual_sample['x1']))
        )
    )

    # Rule 2: If HoursPerWeek is influenced by Age, compute it based on the change in Age
    constraints.append(
        Ite(
            Not(EqualsOrIff(ToReal(model_symbols['interventional']['x11']['symbol']), ToReal(factual_sample['x11']))),
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x11']['symbol']),
                Plus([
                    ToReal(factual_sample['x11']),
                    Times(
                        Minus(
                            ToReal(model_symbols['counterfactual']['x1']['symbol']),
                            ToReal(factual_sample['x1'])
                        ),
                        Real(0.5)  # Weight for age's influence on HoursPerWeek (example coefficient)
                    ),
                ])
            ),
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x11']['symbol']), ToReal(factual_sample['x11']))
        )
    )

    # Rule 3: If Sex is intervened, adjust Relationship (e.g., Sex = Male -> Relationship != Wife)
    constraints.append(
        Ite(
            Not(EqualsOrIff(ToReal(model_symbols['interventional']['x0']['symbol']), ToReal(factual_sample['x0']))),
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), ToReal(model_symbols['interventional']['x0']['symbol'])),
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), ToReal(factual_sample['x0']))
        )
    )

    # Rule 4: If EducationLevel influences Occupation, use structural equation model for counterfactual
    constraints.append(
        Ite(
            Not(EqualsOrIff(ToReal(model_symbols['interventional']['x5']['symbol']), ToReal(factual_sample['x5']))),
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x7']['symbol']),
                Plus([
                    ToReal(factual_sample['x7']),
                    Times(
                        Minus(
                            ToReal(model_symbols['counterfactual']['x5']['symbol']),
                            ToReal(factual_sample['x5'])
                        ),
                        Real(2.5)  # Example coefficient for the effect of EducationLevel on Occupation
                    ),
                ])
            ),
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x7']['symbol']), ToReal(factual_sample['x7']))
        )
    )

    # Combine all constraints into one formula
    causal_consistency_constraints = And(constraints)

    return causal_consistency_constraints
'''

# With Sex Relationship constraint
'''
def getAdultCausalConsistencyConstraints(model_symbols, factual_sample):
    """
    Define causal consistency constraints for the Adult dataset using SEM-like relationships:
    - Sex impacts Relationship.
    - If Sex is Male, Relationship cannot be Wife.
    - If Sex is Female, Relationship cannot be Husband.

    Args:
        model_symbols (dict): Dictionary containing the model symbols for the counterfactual and interventional samples.
        factual_sample (dict): The factual sample from the dataset.

    Returns:
        pysmt.formula.FNode: A conjunction of all causal consistency constraints.
    """
    # Initialize constraints list
    constraints = []

    # Rule 1: If Sex is intervened, then adjust Relationship (e.g., Sex = Male -> Relationship != Wife)
    constraints.append(
        Ite(
            Not(EqualsOrIff(ToReal(model_symbols['interventional']['x0']['symbol']), ToReal(factual_sample['x0']))),  # If Sex is intervened
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), ToReal(model_symbols['interventional']['x0']['symbol'])),  # Set counterfactual to the intervened value
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), ToReal(factual_sample['x0']))  # Else, use factual value
        )
    )

    # Rule 2: If Sex = Male (x0 = 1), Relationship != Wife (x8 ≠ 4)
    constraints.append(
        Ite(
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), Real(1)),  # Sex = Male
            Not(EqualsOrIff(ToReal(model_symbols['counterfactual']['x8']['symbol']), Real(4))),  # Relationship != Wife
            TRUE()  # Else, no constraint
        )
    )

    # Rule 3: If Sex = Female (x0 = 2), Relationship != Husband (x8 ≠ 5)
    constraints.append(
        Ite(
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), Real(2)),  # Sex = Female
            Not(EqualsOrIff(ToReal(model_symbols['counterfactual']['x8']['symbol']), Real(5))),  # Relationship != Husband
            TRUE()  # Else, no constraint
        )
    )

    # Combine all constraints into one formula
    causal_consistency_constraints = And(constraints)

    return causal_consistency_constraints
'''

'''
def getAdultCausalConsistencyConstraints(model_symbols, factual_sample):
    """
    Define causal consistency constraints for the Adult dataset using SEM-like relationships:
    - Sex impacts Relationship.
    - If Sex is Male, Relationship cannot be Wife.
    - If Sex is Female, Relationship cannot be Husband.
    - If Relationship is Husband or Wife, then MaritalStatus cannot be Divorced or Never-Married.

    Args:
        model_symbols (dict): Dictionary containing the model symbols for the counterfactual and interventional samples.
        factual_sample (dict): The factual sample from the dataset.

    Returns:
        pysmt.formula.FNode: A conjunction of all causal consistency constraints.
    """
    # Initialize constraints list
    constraints = []

    # Rule 1: If Sex is intervened, then adjust Relationship (e.g., Sex = Male -> Relationship != Wife)
    constraints.append(
        Ite(
            Not(EqualsOrIff(ToReal(model_symbols['interventional']['x0']['symbol']), ToReal(factual_sample['x0']))),  # If Sex is intervened
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), ToReal(model_symbols['interventional']['x0']['symbol'])),  # Set counterfactual to the intervened value
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), ToReal(factual_sample['x0']))  # Else, use factual value
        )
    )

    # Rule 2: If Sex = Male (x0 = 1), Relationship != Wife (x8 ≠ 4)
    constraints.append(
        Ite(
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), Real(1)),  # Sex = Male
            Not(EqualsOrIff(ToReal(model_symbols['counterfactual']['x8']['symbol']), Real(6))),  # Relationship != Wife
            TRUE()  # Else, no constraint
        )
    )

    # Rule 3: If Sex = Female (x0 = 2), Relationship != Husband (x8 ≠ 5)
    constraints.append(
        Ite(
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), Real(2)),  # Sex = Female
            Not(EqualsOrIff(ToReal(model_symbols['counterfactual']['x8']['symbol']), Real(1))),  # Relationship != Husband
            TRUE()  # Else, no constraint
        )
    )

    # Rule 4: If Relationship is Husband or Wife (x8 = 5 or x8 = 4), then MaritalStatus cannot be Divorced (x6 = 3) or Never-Married (x6 = 1)
    constraints.append(
        Ite(
            Or(
                EqualsOrIff(ToReal(model_symbols['counterfactual']['x8']['symbol']), Real(6)),  # Relationship is Wife (x8 = 4)
                EqualsOrIff(ToReal(model_symbols['counterfactual']['x8']['symbol']), Real(1))   # Relationship is Husband (x8 = 5)
            ),
            Not(Or(
                EqualsOrIff(ToReal(model_symbols['counterfactual']['x6']['symbol']), Real(5)),  # MaritalStatus is Never-Married (x6 = 1)
                EqualsOrIff(ToReal(model_symbols['counterfactual']['x6']['symbol']), Real(1))   # MaritalStatus is Divorced (x6 = 3)
            )),
            TRUE()  # Else, no constraint
        )
    )

    # Combine all constraints into one formula
    causal_consistency_constraints = And(constraints)

    return causal_consistency_constraints
'''

def getAdultCausalConsistencyConstraints(model_symbols, factual_sample):
    """
    Define causal consistency constraints for the Adult dataset using SEM-like relationships:
    - Sex impacts Relationship.
    - If Sex is Male, Relationship cannot be Wife.
    - If Sex is Female, Relationship cannot be Husband.
    - If Relationship is Husband or Wife, then MaritalStatus cannot be Divorced or Never-Married.

    Args:
        model_symbols (dict): Dictionary containing the model symbols for the counterfactual and interventional samples.
        factual_sample (dict): The factual sample from the dataset.

    Returns:
        pysmt.formula.FNode: A conjunction of all causal consistency constraints.
    """
    # Initialize constraints list
    constraints = []

    # Rule 1: If Sex is intervened, then adjust Relationship (e.g., Sex = Male -> Relationship != Wife)
    constraints.append(
        Ite(
            Not(EqualsOrIff(ToReal(model_symbols['interventional']['x0']['symbol']), ToReal(factual_sample['x0']))),  # If Sex is intervened
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), ToReal(model_symbols['interventional']['x0']['symbol'])),  # Set counterfactual to the intervened value
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), ToReal(factual_sample['x0']))  # Else, use factual value
        )
    )

    # Rule 2: If Sex = Male (x0 = 1), Relationship != Wife (x8 ≠ 4)
    constraints.append(
        Ite(
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), Real(1)),  # Sex = Male
            Not(EqualsOrIff(ToReal(model_symbols['counterfactual']['x8']['symbol']), Real(6))),  # Relationship != Wife
            TRUE()  # Else, no constraint
        )
    )

    # Rule 3: If Sex = Female (x0 = 2), Relationship != Husband (x8 ≠ 5)
    constraints.append(
        Ite(
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x0']['symbol']), Real(2)),  # Sex = Female
            Not(EqualsOrIff(ToReal(model_symbols['counterfactual']['x8']['symbol']), Real(1))),  # Relationship != Husband
            TRUE()  # Else, no constraint
        )
    )

    # Rule 4: If Relationship is Husband or Wife (x8 = 5 or x8 = 4), then MaritalStatus cannot be Divorced (x6 = 3) or Never-Married (x6 = 1)
    constraints.append(
        Ite(
            Or(
                EqualsOrIff(ToReal(model_symbols['counterfactual']['x8']['symbol']), Real(6)),  # Relationship is Wife (x8 = 4)
                EqualsOrIff(ToReal(model_symbols['counterfactual']['x8']['symbol']), Real(1))   # Relationship is Husband (x8 = 5)
            ),
            Not(Or(
                EqualsOrIff(ToReal(model_symbols['counterfactual']['x6']['symbol']), Real(5)),  # MaritalStatus is Never-Married (x6 = 1)
                EqualsOrIff(ToReal(model_symbols['counterfactual']['x6']['symbol']), Real(1))   # MaritalStatus is Divorced (x6 = 3)
            )),
            TRUE()  # Else, no constraint
        )
    )
    
    # New Rules: Capital gain/loss constraints
    # If capital gain > 0 then capital loss = 0
    constraints.append(
        Ite(
            GT(ToReal(model_symbols['counterfactual']['x9']['symbol']), Real(0)),
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x10']['symbol']), Real(0)),
            TRUE()
        )
    )

    # If capital loss > 0 then capital gain = 0
    constraints.append(
        Ite(
            GT(ToReal(model_symbols['counterfactual']['x10']['symbol']), Real(0)),
            EqualsOrIff(ToReal(model_symbols['counterfactual']['x9']['symbol']), Real(0)),
            TRUE()
        )
    )
    # Combine all constraints into one formula
    causal_consistency_constraints = And(constraints)

    return causal_consistency_constraints


# # Below is the linear approx SCM to the nonlinear SCM for the random dataset
# def getRandomCausalConsistencyConstraints(model_symbols, factual_sample):
#   # x0 (root node; no parents)
#   x0 = Ite(
#     Not( # if YES intervened
#       EqualsOrIff(
#         ToReal(model_symbols['interventional']['x0']['symbol']),
#         ToReal(factual_sample['x0']),
#       )
#     ),
#     EqualsOrIff( # set value of X^CF to the intervened value
#       ToReal(model_symbols['counterfactual']['x0']['symbol']),
#       ToReal(model_symbols['interventional']['x0']['symbol']),
#     ),
#     EqualsOrIff( # else, set value of X^CF to (8) from paper
#       ToReal(model_symbols['counterfactual']['x0']['symbol']),
#       ToReal(factual_sample['x0']),
#     ),
#   )

#   # x1 (parents = {x0})
#   x1 = Ite(
#     Not( # if YES intervened
#       EqualsOrIff(
#         ToReal(model_symbols['interventional']['x1']['symbol']),
#         ToReal(factual_sample['x1']),
#       )
#     ),
#     EqualsOrIff( # set value of X^CF to the intervened value
#       ToReal(model_symbols['counterfactual']['x1']['symbol']),
#       ToReal(model_symbols['interventional']['x1']['symbol']),
#     ),
#     EqualsOrIff( # else, set value of X^CF to (8) from paper
#       ToReal(model_symbols['counterfactual']['x1']['symbol']),
#       Plus(
#         ToReal(factual_sample['x1']),
#         Times(
#           Minus(
#             ToReal(model_symbols['counterfactual']['x0']['symbol']),
#             ToReal(factual_sample['x0']),
#           ),
#           Real(1)
#         )
#       )
#     ),
#   )

#   # x2 (parents = {x0, x1})
#   x2 = Ite(
#     Not( # if YES intervened
#       EqualsOrIff(
#         ToReal(model_symbols['interventional']['x2']['symbol']),
#         ToReal(factual_sample['x2']),
#       )
#     ),
#     EqualsOrIff( # set value of X^CF to the intervened value
#       ToReal(model_symbols['counterfactual']['x2']['symbol']),
#       ToReal(model_symbols['interventional']['x2']['symbol']),
#     ),
#     EqualsOrIff( # else, set value of X^CF to (8) from paper
#       ToReal(model_symbols['counterfactual']['x2']['symbol']),
#       Plus([
#         ToReal(factual_sample['x2']),
#         Times(
#           Minus(
#             ToReal(model_symbols['counterfactual']['x0']['symbol']),
#             ToReal(factual_sample['x0']),
#           ),
#           Real(5.5)
#         ),
#         Times(
#           Minus(
#             ToReal(model_symbols['counterfactual']['x1']['symbol']),
#             ToReal(factual_sample['x1']),
#           ),
#           Real(3.5)
#         ),
#       ])
#     ),
#   )

#   return And([x0,x1,x2])




def getMortgageCausalConsistencyConstraints(model_symbols, factual_sample):
  a = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x0']['symbol']),
        ToReal(factual_sample['x0']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x0']['symbol']),
      ToReal(model_symbols['interventional']['x0']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x0']['symbol']),
      ToReal(factual_sample['x0']),
    ),
  )

  b = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x1']['symbol']),
        ToReal(factual_sample['x1']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x1']['symbol']),
      ToReal(model_symbols['interventional']['x1']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x1']['symbol']),
      Plus(
        ToReal(factual_sample['x1']),
        Times(
          Minus(
            ToReal(model_symbols['counterfactual']['x0']['symbol']),
            ToReal(factual_sample['x0']),
          ),
          Real(0.3)
        ),
      )
    ),
  )

  return And([a,b])


def getTwoMoonCausalConsistencyConstraints(model_symbols, factual_sample):
  a = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x0']['symbol']),
        ToReal(factual_sample['x0']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x0']['symbol']),
      ToReal(model_symbols['interventional']['x0']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x0']['symbol']),
      ToReal(factual_sample['x0']),
    ),
  )

  b = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x1']['symbol']),
        ToReal(factual_sample['x1']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x1']['symbol']),
      ToReal(model_symbols['interventional']['x1']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x1']['symbol']),
      ToReal(factual_sample['x1']),
    ),
  )

  return And([a,b])


def getTestCausalConsistencyConstraints(model_symbols, factual_sample):
  a = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x0_ord_0']['symbol']),
        ToReal(factual_sample['x0_ord_0']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x0_ord_0']['symbol']),
      ToReal(model_symbols['interventional']['x0_ord_0']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x0_ord_0']['symbol']),
      ToReal(factual_sample['x0_ord_0']),
    ),
  )

  b = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x0_ord_1']['symbol']),
        ToReal(factual_sample['x0_ord_1']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x0_ord_1']['symbol']),
      ToReal(model_symbols['interventional']['x0_ord_1']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x0_ord_1']['symbol']),
      ToReal(factual_sample['x0_ord_1']),
    ),
  )

  c = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x0_ord_2']['symbol']),
        ToReal(factual_sample['x0_ord_2']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x0_ord_2']['symbol']),
      ToReal(model_symbols['interventional']['x0_ord_2']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x0_ord_2']['symbol']),
      ToReal(factual_sample['x0_ord_2']),
    ),
  )

  d = Ite(
    Not( # if YES intervened
      EqualsOrIff(
        ToReal(model_symbols['interventional']['x0_ord_3']['symbol']),
        ToReal(factual_sample['x0_ord_3']),
      )
    ),
    EqualsOrIff( # set value of X^CF to the intervened value
      ToReal(model_symbols['counterfactual']['x0_ord_3']['symbol']),
      ToReal(model_symbols['interventional']['x0_ord_3']['symbol']),
    ),
    EqualsOrIff( # else, set value of X^CF to (8) from paper
      ToReal(model_symbols['counterfactual']['x0_ord_3']['symbol']),
      ToReal(factual_sample['x0_ord_3']),
    ),
  )

  return And([a,b,c,d])

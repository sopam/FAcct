To run the adult dataset using mint:
python batchTest.py -d adult -m tree -n one_norm -a MINT__eps_1e-3 -b 0 -s 10

To run the adult dataset using mace:
python batchTest.py -d adult -m tree -n one_norm -a MACE__eps_1e-3 -b 0 -s 10


To run the german dataset using mint:
python batchTest.py -d german -m tree -n one_norm -a MINT__eps_1e-3 -b 0 -s 10

To run the german dataset using mace:
python batchTest.py -d german -m tree -n one_norm -a MACE__eps_1e-3 -b 0 -s 10

The results will be in folder: _experiments
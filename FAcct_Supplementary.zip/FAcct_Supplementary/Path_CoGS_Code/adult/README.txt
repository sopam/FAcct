1) This is the proof of concept to show we can show the states from initial to final in a series.
2) get_path.pl contains the function get_path() that will return the path to the counterfactual state for a given input.
3) T1 must be specified to a integer value. Leaving it unassigned will cause the function to fail.
4) To run, ensure that you are in the same directory as all the files
Run by the following command in the terminal:
scasp get_path.pl -s0

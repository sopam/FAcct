1) To run, ensure that you are in the same directory as all the files i.e. Inside folder Adult, German or Car_evaluation
2) Run by the following command in the terminal to get the path to the counterfactual:
scasp get_path.pl -s0

